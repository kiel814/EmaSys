﻿namespace CapaPresentacion
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
			this.menuStrip = new System.Windows.Forms.MenuStrip();
			this.MnuSistema = new System.Windows.Forms.ToolStripMenuItem();
			this.salirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuCompras = new System.Windows.Forms.ToolStripMenuItem();
			this.proveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.facturasDeProveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.notasDeCréditoDeProveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.notasDeDébitoDeProveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuVentas = new System.Windows.Forms.ToolStripMenuItem();
			this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuMantenimiento = new System.Windows.Forms.ToolStripMenuItem();
			this.empleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuVer = new System.Windows.Forms.ToolStripMenuItem();
			this.toolBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHerramientas = new System.Windows.Forms.ToolStripMenuItem();
			this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.backUpBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.migraciónClientesFOXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.migraciónProveedoresFOXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuVentanas = new System.Windows.Forms.ToolStripMenuItem();
			this.newWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.arrangeIconsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuAyuda = new System.Windows.Forms.ToolStripMenuItem();
			this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStrip = new System.Windows.Forms.ToolStrip();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.TsCompras = new System.Windows.Forms.ToolStripButton();
			this.TsVentas = new System.Windows.Forms.ToolStripButton();
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.órdenesDePagoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip.SuspendLayout();
			this.toolStrip.SuspendLayout();
			this.statusStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip
			// 
			this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSistema,
            this.MnuCompras,
            this.MnuVentas,
            this.MnuMantenimiento,
            this.MnuVer,
            this.MnuHerramientas,
            this.MnuVentanas,
            this.MnuAyuda});
			this.menuStrip.Location = new System.Drawing.Point(0, 0);
			this.menuStrip.MdiWindowListItem = this.MnuVentanas;
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new System.Drawing.Size(689, 24);
			this.menuStrip.TabIndex = 0;
			this.menuStrip.Text = "MenuStrip";
			// 
			// MnuSistema
			// 
			this.MnuSistema.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirToolStripMenuItem1});
			this.MnuSistema.Image = global::CapaPresentacion.Properties.Resources.FileGroup_16x;
			this.MnuSistema.Name = "MnuSistema";
			this.MnuSistema.Size = new System.Drawing.Size(135, 20);
			this.MnuSistema.Text = "Sistema de Gestión";
			// 
			// salirToolStripMenuItem1
			// 
			this.salirToolStripMenuItem1.Image = global::CapaPresentacion.Properties.Resources.Cancel_16xMD;
			this.salirToolStripMenuItem1.Name = "salirToolStripMenuItem1";
			this.salirToolStripMenuItem1.Size = new System.Drawing.Size(104, 22);
			this.salirToolStripMenuItem1.Text = "&SALIR";
			this.salirToolStripMenuItem1.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
			// 
			// MnuCompras
			// 
			this.MnuCompras.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.proveedorToolStripMenuItem,
            this.facturasDeProveedoresToolStripMenuItem,
            this.notasDeCréditoDeProveedoresToolStripMenuItem,
            this.notasDeDébitoDeProveedoresToolStripMenuItem,
            this.órdenesDePagoToolStripMenuItem});
			this.MnuCompras.Image = global::CapaPresentacion.Properties.Resources.Structure_16x;
			this.MnuCompras.Name = "MnuCompras";
			this.MnuCompras.Size = new System.Drawing.Size(83, 20);
			this.MnuCompras.Text = "Compras";
			// 
			// proveedorToolStripMenuItem
			// 
			this.proveedorToolStripMenuItem.Name = "proveedorToolStripMenuItem";
			this.proveedorToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
			this.proveedorToolStripMenuItem.Text = "Proveedores";
			this.proveedorToolStripMenuItem.Click += new System.EventHandler(this.proveedorToolStripMenuItem_Click);
			// 
			// facturasDeProveedoresToolStripMenuItem
			// 
			this.facturasDeProveedoresToolStripMenuItem.Name = "facturasDeProveedoresToolStripMenuItem";
			this.facturasDeProveedoresToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
			this.facturasDeProveedoresToolStripMenuItem.Text = "Facturas de Proveedores";
			this.facturasDeProveedoresToolStripMenuItem.Click += new System.EventHandler(this.facturasProveedoresToolStripMenuItem_Click);
			// 
			// notasDeCréditoDeProveedoresToolStripMenuItem
			// 
			this.notasDeCréditoDeProveedoresToolStripMenuItem.Name = "notasDeCréditoDeProveedoresToolStripMenuItem";
			this.notasDeCréditoDeProveedoresToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
			this.notasDeCréditoDeProveedoresToolStripMenuItem.Text = "Notas de Crédito de Proveedores";
			this.notasDeCréditoDeProveedoresToolStripMenuItem.Click += new System.EventHandler(this.notasDeCreditoDeProveedoresToolStripMenuItem_Click);
			// 
			// notasDeDébitoDeProveedoresToolStripMenuItem
			// 
			this.notasDeDébitoDeProveedoresToolStripMenuItem.Name = "notasDeDébitoDeProveedoresToolStripMenuItem";
			this.notasDeDébitoDeProveedoresToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
			this.notasDeDébitoDeProveedoresToolStripMenuItem.Text = "Notas de Débito de Proveedores";
			this.notasDeDébitoDeProveedoresToolStripMenuItem.Click += new System.EventHandler(this.notasDeDebitoDeProveedoresToolStripMenuItem_Click);
			// 
			// MnuVentas
			// 
			this.MnuVentas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem});
			this.MnuVentas.Image = global::CapaPresentacion.Properties.Resources.Team_16x;
			this.MnuVentas.Name = "MnuVentas";
			this.MnuVentas.Size = new System.Drawing.Size(69, 20);
			this.MnuVentas.Text = "Ventas";
			// 
			// clientesToolStripMenuItem
			// 
			this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
			this.clientesToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
			this.clientesToolStripMenuItem.Text = "Clientes";
			this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
			// 
			// MnuMantenimiento
			// 
			this.MnuMantenimiento.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empleadosToolStripMenuItem});
			this.MnuMantenimiento.Name = "MnuMantenimiento";
			this.MnuMantenimiento.Size = new System.Drawing.Size(101, 20);
			this.MnuMantenimiento.Text = "Mantenimiento";
			// 
			// empleadosToolStripMenuItem
			// 
			this.empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
			this.empleadosToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			this.empleadosToolStripMenuItem.Text = "&Empleados";
			this.empleadosToolStripMenuItem.Click += new System.EventHandler(this.empleadosToolStripMenuItem_Click);
			// 
			// MnuVer
			// 
			this.MnuVer.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolBarToolStripMenuItem,
            this.statusBarToolStripMenuItem});
			this.MnuVer.Name = "MnuVer";
			this.MnuVer.Size = new System.Drawing.Size(35, 20);
			this.MnuVer.Text = "&Ver";
			// 
			// toolBarToolStripMenuItem
			// 
			this.toolBarToolStripMenuItem.Checked = true;
			this.toolBarToolStripMenuItem.CheckOnClick = true;
			this.toolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolBarToolStripMenuItem.Name = "toolBarToolStripMenuItem";
			this.toolBarToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.toolBarToolStripMenuItem.Text = "&Barra de herramientas";
			this.toolBarToolStripMenuItem.Click += new System.EventHandler(this.ToolBarToolStripMenuItem_Click);
			// 
			// statusBarToolStripMenuItem
			// 
			this.statusBarToolStripMenuItem.Checked = true;
			this.statusBarToolStripMenuItem.CheckOnClick = true;
			this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
			this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
			this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.statusBarToolStripMenuItem.Text = "&Barra de estado";
			this.statusBarToolStripMenuItem.Click += new System.EventHandler(this.StatusBarToolStripMenuItem_Click);
			// 
			// MnuHerramientas
			// 
			this.MnuHerramientas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.migraciónClientesFOXToolStripMenuItem,
            this.migraciónProveedoresFOXToolStripMenuItem});
			this.MnuHerramientas.Name = "MnuHerramientas";
			this.MnuHerramientas.Size = new System.Drawing.Size(90, 20);
			this.MnuHerramientas.Text = "&Herramientas";
			// 
			// optionsToolStripMenuItem
			// 
			this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backUpBDToolStripMenuItem});
			this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
			this.optionsToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
			this.optionsToolStripMenuItem.Text = "&BD";
			// 
			// backUpBDToolStripMenuItem
			// 
			this.backUpBDToolStripMenuItem.Name = "backUpBDToolStripMenuItem";
			this.backUpBDToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
			this.backUpBDToolStripMenuItem.Text = "BackUp BD";
			// 
			// migraciónClientesFOXToolStripMenuItem
			// 
			this.migraciónClientesFOXToolStripMenuItem.Name = "migraciónClientesFOXToolStripMenuItem";
			this.migraciónClientesFOXToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
			this.migraciónClientesFOXToolStripMenuItem.Text = "Migración &Clientes FOX";
			this.migraciónClientesFOXToolStripMenuItem.Click += new System.EventHandler(this.migraciónClientesFOXToolStripMenuItem_Click);
			// 
			// migraciónProveedoresFOXToolStripMenuItem
			// 
			this.migraciónProveedoresFOXToolStripMenuItem.Name = "migraciónProveedoresFOXToolStripMenuItem";
			this.migraciónProveedoresFOXToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
			this.migraciónProveedoresFOXToolStripMenuItem.Text = "Migración &Proveedores FOX";
			this.migraciónProveedoresFOXToolStripMenuItem.Click += new System.EventHandler(this.migraciónProveedoresFOXToolStripMenuItem_Click);
			// 
			// MnuVentanas
			// 
			this.MnuVentanas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newWindowToolStripMenuItem,
            this.cascadeToolStripMenuItem,
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.closeAllToolStripMenuItem,
            this.arrangeIconsToolStripMenuItem});
			this.MnuVentanas.Name = "MnuVentanas";
			this.MnuVentanas.Size = new System.Drawing.Size(66, 20);
			this.MnuVentanas.Text = "&Ventanas";
			// 
			// newWindowToolStripMenuItem
			// 
			this.newWindowToolStripMenuItem.Name = "newWindowToolStripMenuItem";
			this.newWindowToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.newWindowToolStripMenuItem.Text = "&Nueva ventana";
			this.newWindowToolStripMenuItem.Click += new System.EventHandler(this.ShowNewForm);
			// 
			// cascadeToolStripMenuItem
			// 
			this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
			this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.cascadeToolStripMenuItem.Text = "&Cascada";
			this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.CascadeToolStripMenuItem_Click);
			// 
			// tileVerticalToolStripMenuItem
			// 
			this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
			this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.tileVerticalToolStripMenuItem.Text = "Mosaico &vertical";
			this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.TileVerticalToolStripMenuItem_Click);
			// 
			// tileHorizontalToolStripMenuItem
			// 
			this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
			this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.tileHorizontalToolStripMenuItem.Text = "Mosaico &horizontal";
			this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
			// 
			// closeAllToolStripMenuItem
			// 
			this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
			this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.closeAllToolStripMenuItem.Text = "C&errar todo";
			this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
			// 
			// arrangeIconsToolStripMenuItem
			// 
			this.arrangeIconsToolStripMenuItem.Name = "arrangeIconsToolStripMenuItem";
			this.arrangeIconsToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
			this.arrangeIconsToolStripMenuItem.Text = "&Organizar iconos";
			this.arrangeIconsToolStripMenuItem.Click += new System.EventHandler(this.ArrangeIconsToolStripMenuItem_Click);
			// 
			// MnuAyuda
			// 
			this.MnuAyuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indexToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
			this.MnuAyuda.Name = "MnuAyuda";
			this.MnuAyuda.Size = new System.Drawing.Size(53, 20);
			this.MnuAyuda.Text = "Ay&uda";
			// 
			// indexToolStripMenuItem
			// 
			this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
			this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
			this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
			this.indexToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.indexToolStripMenuItem.Text = "&Índice";
			// 
			// toolStripSeparator8
			// 
			this.toolStripSeparator8.Name = "toolStripSeparator8";
			this.toolStripSeparator8.Size = new System.Drawing.Size(144, 6);
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.aboutToolStripMenuItem.Text = "&Acerca de... ...";
			// 
			// toolStrip
			// 
			this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.TsCompras,
            this.TsVentas});
			this.toolStrip.Location = new System.Drawing.Point(0, 24);
			this.toolStrip.Name = "toolStrip";
			this.toolStrip.Size = new System.Drawing.Size(689, 25);
			this.toolStrip.TabIndex = 1;
			this.toolStrip.Text = "ToolStrip";
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
			// 
			// TsCompras
			// 
			this.TsCompras.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsCompras.Image = global::CapaPresentacion.Properties.Resources.Structure_16x;
			this.TsCompras.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsCompras.Name = "TsCompras";
			this.TsCompras.Size = new System.Drawing.Size(23, 22);
			this.TsCompras.Text = "Proveedores";
			this.TsCompras.Click += new System.EventHandler(this.TsCompras_Click);
			// 
			// TsVentas
			// 
			this.TsVentas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsVentas.Image = global::CapaPresentacion.Properties.Resources.Team_16x;
			this.TsVentas.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsVentas.Name = "TsVentas";
			this.TsVentas.Size = new System.Drawing.Size(23, 22);
			this.TsVentas.Text = "Clientes";
			this.TsVentas.Click += new System.EventHandler(this.TsVentas_Click);
			// 
			// statusStrip
			// 
			this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
			this.statusStrip.Location = new System.Drawing.Point(0, 431);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new System.Drawing.Size(689, 22);
			this.statusStrip.TabIndex = 2;
			this.statusStrip.Text = "StatusStrip";
			// 
			// toolStripStatusLabel
			// 
			this.toolStripStatusLabel.Name = "toolStripStatusLabel";
			this.toolStripStatusLabel.Size = new System.Drawing.Size(203, 17);
			this.toolStripStatusLabel.Text = ".::  EMA SA  .::.  Sistema de Gestión  ::.";
			// 
			// órdenesDePagoToolStripMenuItem
			// 
			this.órdenesDePagoToolStripMenuItem.Name = "órdenesDePagoToolStripMenuItem";
			this.órdenesDePagoToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
			this.órdenesDePagoToolStripMenuItem.Text = "Órdenes de Pago";
			this.órdenesDePagoToolStripMenuItem.Click += new System.EventHandler(this.órdenesDePagoToolStripMenuItem_Click);
			// 
			// FrmPrincipal
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(689, 453);
			this.Controls.Add(this.statusStrip);
			this.Controls.Add(this.toolStrip);
			this.Controls.Add(this.menuStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.MainMenuStrip = this.menuStrip;
			this.Name = "FrmPrincipal";
			this.Text = ".::  EMA SA ::.  .::  Sistema de Gestión  ::.";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmPrincipal_FormClosed);
			this.Load += new System.EventHandler(this.FrmPrincipal_Load);
			this.menuStrip.ResumeLayout(false);
			this.menuStrip.PerformLayout();
			this.toolStrip.ResumeLayout(false);
			this.toolStrip.PerformLayout();
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuVer;
        private System.Windows.Forms.ToolStripMenuItem toolBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuHerramientas;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuVentanas;
        private System.Windows.Forms.ToolStripMenuItem newWindowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrangeIconsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuAyuda;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem MnuSistema;
        private System.Windows.Forms.ToolStripMenuItem MnuCompras;
        private System.Windows.Forms.ToolStripMenuItem proveedorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuVentas;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backUpBDToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TsCompras;
        private System.Windows.Forms.ToolStripButton TsVentas;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MnuMantenimiento;
        private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem migraciónClientesFOXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem migraciónProveedoresFOXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturasDeProveedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem notasDeCréditoDeProveedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem notasDeDébitoDeProveedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem órdenesDePagoToolStripMenuItem;
	}
}



