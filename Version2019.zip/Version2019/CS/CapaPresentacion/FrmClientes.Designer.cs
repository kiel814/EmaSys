﻿namespace CapaPresentacion
{
    partial class FrmClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnImprimirNombreCli = new System.Windows.Forms.Button();
            this.btnImprimirCodClien = new System.Windows.Forms.Button();
            this.cboBuscar = new System.Windows.Forms.ComboBox();
            this.dataListado = new System.Windows.Forms.DataGridView();
            this.Eliminar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lblTotal = new System.Windows.Forms.Label();
            this.chkEliminar = new System.Windows.Forms.CheckBox();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCliPais = new System.Windows.Forms.TextBox();
            this.txtCliCodigo = new System.Windows.Forms.TextBox();
            this.txtCliProvi = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtCliAgper = new System.Windows.Forms.ComboBox();
            this.txtCliCIva = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCliTecom = new System.Windows.Forms.TextBox();
            this.txtCliMail = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtCliOk = new System.Windows.Forms.TextBox();
            this.txtCliTeadm = new System.Windows.Forms.TextBox();
            this.txtCliCoadm = new System.Windows.Forms.TextBox();
            this.txtCliTetec = new System.Windows.Forms.TextBox();
            this.txtCliCotec = new System.Windows.Forms.TextBox();
            this.txtCliCocom = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCliPCobr = new System.Windows.Forms.TextBox();
            this.txtCliProve = new System.Windows.Forms.TextBox();
            this.txtCliIngbr = new System.Windows.Forms.TextBox();
            this.txtCliCuit = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCliCPost = new System.Windows.Forms.TextBox();
            this.txtCliLocal = new System.Windows.Forms.TextBox();
            this.txtCliFax = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCliTelef = new System.Windows.Forms.TextBox();
            this.txtCliDirec = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.txtCliNombr = new System.Windows.Forms.TextBox();
            this.txtClienteID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.errorIcono = new System.Windows.Forms.ErrorProvider(this.components);
            this.ttMensaje = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListado)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorIcono)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(32, 61);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(852, 442);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnImprimirNombreCli);
            this.tabPage1.Controls.Add(this.btnImprimirCodClien);
            this.tabPage1.Controls.Add(this.cboBuscar);
            this.tabPage1.Controls.Add(this.dataListado);
            this.tabPage1.Controls.Add(this.lblTotal);
            this.tabPage1.Controls.Add(this.chkEliminar);
            this.tabPage1.Controls.Add(this.btnImprimir);
            this.tabPage1.Controls.Add(this.btnEliminar);
            this.tabPage1.Controls.Add(this.btnBuscar);
            this.tabPage1.Controls.Add(this.txtBuscar);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(844, 416);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Listado";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnImprimirNombreCli
            // 
            this.btnImprimirNombreCli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnImprimirNombreCli.Image = global::CapaPresentacion.Properties.Resources.Print_16x;
            this.btnImprimirNombreCli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImprimirNombreCli.Location = new System.Drawing.Point(681, 75);
            this.btnImprimirNombreCli.Name = "btnImprimirNombreCli";
            this.btnImprimirNombreCli.Size = new System.Drawing.Size(124, 23);
            this.btnImprimirNombreCli.TabIndex = 10;
            this.btnImprimirNombreCli.Text = "&Imprimir por Nombre";
            this.btnImprimirNombreCli.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImprimirNombreCli.UseVisualStyleBackColor = false;
            this.btnImprimirNombreCli.Click += new System.EventHandler(this.btnImprimirNombreCli_Click);
            // 
            // btnImprimirCodClien
            // 
            this.btnImprimirCodClien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnImprimirCodClien.Image = global::CapaPresentacion.Properties.Resources.Print_16x;
            this.btnImprimirCodClien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImprimirCodClien.Location = new System.Drawing.Point(547, 75);
            this.btnImprimirCodClien.Name = "btnImprimirCodClien";
            this.btnImprimirCodClien.Size = new System.Drawing.Size(124, 23);
            this.btnImprimirCodClien.TabIndex = 9;
            this.btnImprimirCodClien.Text = "&Imprimir por Código";
            this.btnImprimirCodClien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImprimirCodClien.UseVisualStyleBackColor = false;
            this.btnImprimirCodClien.Click += new System.EventHandler(this.btnImprimirCodClien_Click);
            // 
            // cboBuscar
            // 
            this.cboBuscar.FormattingEnabled = true;
            this.cboBuscar.Items.AddRange(new object[] {
            "Nombre",
            "Código",
            "CUIT"});
            this.cboBuscar.Location = new System.Drawing.Point(35, 35);
            this.cboBuscar.Name = "cboBuscar";
            this.cboBuscar.Size = new System.Drawing.Size(69, 21);
            this.cboBuscar.TabIndex = 8;
            this.cboBuscar.Text = "Nombre";
            // 
            // dataListado
            // 
            this.dataListado.AllowUserToAddRows = false;
            this.dataListado.AllowUserToDeleteRows = false;
            this.dataListado.AllowUserToOrderColumns = true;
            this.dataListado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListado.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Eliminar});
            this.dataListado.Location = new System.Drawing.Point(35, 107);
            this.dataListado.MultiSelect = false;
            this.dataListado.Name = "dataListado";
            this.dataListado.ReadOnly = true;
            this.dataListado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataListado.Size = new System.Drawing.Size(773, 281);
            this.dataListado.TabIndex = 7;
            this.dataListado.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataListado_CellContentClick);
            this.dataListado.DoubleClick += new System.EventHandler(this.dataListado_DoubleClick);
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "Eliminar";
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.ReadOnly = true;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(119, 85);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(35, 13);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "label3";
            // 
            // chkEliminar
            // 
            this.chkEliminar.AutoSize = true;
            this.chkEliminar.Location = new System.Drawing.Point(35, 84);
            this.chkEliminar.Name = "chkEliminar";
            this.chkEliminar.Size = new System.Drawing.Size(62, 17);
            this.chkEliminar.TabIndex = 5;
            this.chkEliminar.Text = "Eliminar";
            this.chkEliminar.UseVisualStyleBackColor = true;
            this.chkEliminar.CheckedChanged += new System.EventHandler(this.chkEliminar_CheckedChanged);
            // 
            // btnImprimir
            // 
            this.btnImprimir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnImprimir.Image = global::CapaPresentacion.Properties.Resources.Print_16x;
            this.btnImprimir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImprimir.Location = new System.Drawing.Point(681, 35);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(124, 23);
            this.btnImprimir.TabIndex = 4;
            this.btnImprimir.Text = "&Imprimir Completo";
            this.btnImprimir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImprimir.UseVisualStyleBackColor = false;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Image = global::CapaPresentacion.Properties.Resources.DeleteListItem_16x;
            this.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminar.Location = new System.Drawing.Point(596, 35);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 3;
            this.btnEliminar.Text = "&Eliminar";
            this.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Image = global::CapaPresentacion.Properties.Resources.FindSymbol_16x;
            this.btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscar.Location = new System.Drawing.Point(515, 35);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "&Buscar";
            this.btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(122, 35);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(275, 20);
            this.txtBuscar.TabIndex = 1;
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(844, 416);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mantenimiento";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCliPais);
            this.groupBox1.Controls.Add(this.txtCliCodigo);
            this.groupBox1.Controls.Add(this.txtCliProvi);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.txtCliAgper);
            this.groupBox1.Controls.Add(this.txtCliCIva);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCliTecom);
            this.groupBox1.Controls.Add(this.txtCliMail);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtCliOk);
            this.groupBox1.Controls.Add(this.txtCliTeadm);
            this.groupBox1.Controls.Add(this.txtCliCoadm);
            this.groupBox1.Controls.Add(this.txtCliTetec);
            this.groupBox1.Controls.Add(this.txtCliCotec);
            this.groupBox1.Controls.Add(this.txtCliCocom);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtCliPCobr);
            this.groupBox1.Controls.Add(this.txtCliProve);
            this.groupBox1.Controls.Add(this.txtCliIngbr);
            this.groupBox1.Controls.Add(this.txtCliCuit);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtCliCPost);
            this.groupBox1.Controls.Add(this.txtCliLocal);
            this.groupBox1.Controls.Add(this.txtCliFax);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtCliTelef);
            this.groupBox1.Controls.Add(this.txtCliDirec);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btnCancelar);
            this.groupBox1.Controls.Add(this.btnEditar);
            this.groupBox1.Controls.Add(this.btnGuardar);
            this.groupBox1.Controls.Add(this.btnNuevo);
            this.groupBox1.Controls.Add(this.txtCliNombr);
            this.groupBox1.Controls.Add(this.txtClienteID);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(22, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 391);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clientes";
            // 
            // txtCliPais
            // 
            this.txtCliPais.AutoCompleteCustomSource.AddRange(new string[] {
            "ARGENTINA",
            "BOLIVIA",
            "BRASIL",
            "CHILE",
            "URUGUAY",
            "PARAGUAY"});
            this.txtCliPais.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCliPais.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCliPais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliPais.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliPais.Location = new System.Drawing.Point(439, 102);
            this.txtCliPais.Name = "txtCliPais";
            this.txtCliPais.Size = new System.Drawing.Size(129, 20);
            this.txtCliPais.TabIndex = 7;
            // 
            // txtCliCodigo
            // 
            this.txtCliCodigo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCodigo.Location = new System.Drawing.Point(261, 34);
            this.txtCliCodigo.Name = "txtCliCodigo";
            this.txtCliCodigo.Size = new System.Drawing.Size(81, 20);
            this.txtCliCodigo.TabIndex = 2;
            this.txtCliCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCliCodigo_KeyPress);
            this.txtCliCodigo.Leave += new System.EventHandler(this.txtCliCodigo_Leave);
            this.txtCliCodigo.Validating += new System.ComponentModel.CancelEventHandler(this.txtCliCodigo_Validating);
            // 
            // txtCliProvi
            // 
            this.txtCliProvi.AutoCompleteCustomSource.AddRange(new string[] {
            "BUENOS AIRES",
            "CATAMARCA",
            "CÓRDOBA",
            "CORRIENTES",
            "FORMOSA",
            "MENDOZA",
            "TIERRA DEL FUEGO"});
            this.txtCliProvi.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCliProvi.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCliProvi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliProvi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliProvi.Location = new System.Drawing.Point(656, 70);
            this.txtCliProvi.Name = "txtCliProvi";
            this.txtCliProvi.Size = new System.Drawing.Size(118, 20);
            this.txtCliProvi.TabIndex = 6;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(401, 106);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(32, 13);
            this.label26.TabIndex = 77;
            this.label26.Text = "País:";
            // 
            // txtCliAgper
            // 
            this.txtCliAgper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliAgper.FormattingEnabled = true;
            this.txtCliAgper.Items.AddRange(new object[] {
            "S",
            "N"});
            this.txtCliAgper.Location = new System.Drawing.Point(631, 198);
            this.txtCliAgper.Name = "txtCliAgper";
            this.txtCliAgper.Size = new System.Drawing.Size(54, 21);
            this.txtCliAgper.TabIndex = 17;
            // 
            // txtCliCIva
            // 
            this.txtCliCIva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCIva.FormattingEnabled = true;
            this.txtCliCIva.Items.AddRange(new object[] {
            "I",
            "N",
            "E",
            "C  ",
            "X "});
            this.txtCliCIva.Location = new System.Drawing.Point(438, 198);
            this.txtCliCIva.Name = "txtCliCIva";
            this.txtCliCIva.Size = new System.Drawing.Size(60, 21);
            this.txtCliCIva.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 50;
            this.label2.Text = "Contactos en :";
            // 
            // txtCliTecom
            // 
            this.txtCliTecom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliTecom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliTecom.Location = new System.Drawing.Point(642, 243);
            this.txtCliTecom.Name = "txtCliTecom";
            this.txtCliTecom.Size = new System.Drawing.Size(131, 20);
            this.txtCliTecom.TabIndex = 19;
            // 
            // txtCliMail
            // 
            this.txtCliMail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliMail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliMail.Location = new System.Drawing.Point(438, 166);
            this.txtCliMail.Name = "txtCliMail";
            this.txtCliMail.Size = new System.Drawing.Size(335, 20);
            this.txtCliMail.TabIndex = 15;
            this.txtCliMail.Validating += new System.ComponentModel.CancelEventHandler(this.txtCliMail_Validating);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(398, 170);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 48;
            this.label25.Text = "Email:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(96, 354);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(22, 13);
            this.label24.TabIndex = 47;
            this.label24.Text = "OK";
            this.label24.Visible = false;
            // 
            // txtCliOk
            // 
            this.txtCliOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCliOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliOk.Location = new System.Drawing.Point(129, 350);
            this.txtCliOk.Name = "txtCliOk";
            this.txtCliOk.Size = new System.Drawing.Size(43, 20);
            this.txtCliOk.TabIndex = 25;
            this.txtCliOk.Visible = false;
            // 
            // txtCliTeadm
            // 
            this.txtCliTeadm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliTeadm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliTeadm.Location = new System.Drawing.Point(641, 302);
            this.txtCliTeadm.Name = "txtCliTeadm";
            this.txtCliTeadm.Size = new System.Drawing.Size(132, 20);
            this.txtCliTeadm.TabIndex = 23;
            // 
            // txtCliCoadm
            // 
            this.txtCliCoadm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCoadm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliCoadm.Location = new System.Drawing.Point(93, 302);
            this.txtCliCoadm.Name = "txtCliCoadm";
            this.txtCliCoadm.Size = new System.Drawing.Size(405, 20);
            this.txtCliCoadm.TabIndex = 22;
            // 
            // txtCliTetec
            // 
            this.txtCliTetec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliTetec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliTetec.Location = new System.Drawing.Point(641, 273);
            this.txtCliTetec.Name = "txtCliTetec";
            this.txtCliTetec.Size = new System.Drawing.Size(132, 20);
            this.txtCliTetec.TabIndex = 21;
            // 
            // txtCliCotec
            // 
            this.txtCliCotec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCotec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliCotec.Location = new System.Drawing.Point(93, 273);
            this.txtCliCotec.Name = "txtCliCotec";
            this.txtCliCotec.Size = new System.Drawing.Size(405, 20);
            this.txtCliCotec.TabIndex = 20;
            // 
            // txtCliCocom
            // 
            this.txtCliCocom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCocom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliCocom.Location = new System.Drawing.Point(93, 243);
            this.txtCliCocom.Name = "txtCliCocom";
            this.txtCliCocom.Size = new System.Drawing.Size(405, 20);
            this.txtCliCocom.TabIndex = 18;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(598, 306);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 13);
            this.label23.TabIndex = 39;
            this.label23.Text = "TEL:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 306);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Administración:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(598, 277);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 13);
            this.label21.TabIndex = 37;
            this.label21.Text = "TEL:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 277);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 36;
            this.label20.Text = "Técnico:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(598, 247);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 35;
            this.label19.Text = "TEL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 247);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 34;
            this.label18.Text = "Compras:";
            // 
            // txtCliPCobr
            // 
            this.txtCliPCobr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliPCobr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliPCobr.Location = new System.Drawing.Point(252, 133);
            this.txtCliPCobr.Name = "txtCliPCobr";
            this.txtCliPCobr.Size = new System.Drawing.Size(58, 20);
            this.txtCliPCobr.TabIndex = 10;
            // 
            // txtCliProve
            // 
            this.txtCliProve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliProve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliProve.Location = new System.Drawing.Point(78, 133);
            this.txtCliProve.Name = "txtCliProve";
            this.txtCliProve.Size = new System.Drawing.Size(83, 20);
            this.txtCliProve.TabIndex = 9;
            // 
            // txtCliIngbr
            // 
            this.txtCliIngbr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliIngbr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliIngbr.Location = new System.Drawing.Point(252, 166);
            this.txtCliIngbr.Name = "txtCliIngbr";
            this.txtCliIngbr.Size = new System.Drawing.Size(100, 20);
            this.txtCliIngbr.TabIndex = 14;
            // 
            // txtCliCuit
            // 
            this.txtCliCuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCuit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliCuit.Location = new System.Drawing.Point(78, 166);
            this.txtCliCuit.Name = "txtCliCuit";
            this.txtCliCuit.Size = new System.Drawing.Size(109, 20);
            this.txtCliCuit.TabIndex = 13;
            this.txtCliCuit.TextChanged += new System.EventHandler(this.txtCliCuit_TextChanged);
            this.txtCliCuit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCliCuit_KeyPress);
            this.txtCliCuit.Validating += new System.ComponentModel.CancelEventHandler(this.txtCliCuit_Validating);
            this.txtCliCuit.Validated += new System.EventHandler(this.txtCliCuit_Validated);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(199, 137);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "P.Cobro:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 137);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "N°Proveedor:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(206, 170);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "Ing.Br.:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 170);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "CUIT:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(554, 202);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "AgPer <S/N>:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(406, 202);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "IVA:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(588, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Cód.Postal:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(595, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Provincia:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(377, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Localidad:";
            // 
            // txtCliCPost
            // 
            this.txtCliCPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliCPost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliCPost.Location = new System.Drawing.Point(656, 102);
            this.txtCliCPost.Name = "txtCliCPost";
            this.txtCliCPost.Size = new System.Drawing.Size(117, 20);
            this.txtCliCPost.TabIndex = 8;
            // 
            // txtCliLocal
            // 
            this.txtCliLocal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliLocal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliLocal.Location = new System.Drawing.Point(439, 70);
            this.txtCliLocal.Name = "txtCliLocal";
            this.txtCliLocal.Size = new System.Drawing.Size(150, 20);
            this.txtCliLocal.TabIndex = 5;
            // 
            // txtCliFax
            // 
            this.txtCliFax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliFax.Location = new System.Drawing.Point(656, 133);
            this.txtCliFax.Name = "txtCliFax";
            this.txtCliFax.Size = new System.Drawing.Size(118, 20);
            this.txtCliFax.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(622, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Fax:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(381, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Teléfono:";
            // 
            // txtCliTelef
            // 
            this.txtCliTelef.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliTelef.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliTelef.Location = new System.Drawing.Point(438, 133);
            this.txtCliTelef.Name = "txtCliTelef";
            this.txtCliTelef.Size = new System.Drawing.Size(130, 20);
            this.txtCliTelef.TabIndex = 11;
            // 
            // txtCliDirec
            // 
            this.txtCliDirec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliDirec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliDirec.Location = new System.Drawing.Point(78, 72);
            this.txtCliDirec.Multiline = true;
            this.txtCliDirec.Name = "txtCliDirec";
            this.txtCliDirec.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCliDirec.Size = new System.Drawing.Size(283, 49);
            this.txtCliDirec.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Dirección:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = global::CapaPresentacion.Properties.Resources.Cancel_16x;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(695, 349);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 27;
            this.btnCancelar.Text = "&Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Image = global::CapaPresentacion.Properties.Resources.Edit_16x;
            this.btnEditar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditar.Location = new System.Drawing.Point(596, 349);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(75, 23);
            this.btnEditar.TabIndex = 26;
            this.btnEditar.Text = "E&ditar";
            this.btnEditar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = global::CapaPresentacion.Properties.Resources.Save_16x;
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardar.Location = new System.Drawing.Point(497, 349);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 25;
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Image = global::CapaPresentacion.Properties.Resources.NewFile_16x;
            this.btnNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevo.Location = new System.Drawing.Point(398, 349);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnNuevo.TabIndex = 24;
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // txtCliNombr
            // 
            this.txtCliNombr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtCliNombr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliNombr.Location = new System.Drawing.Point(438, 33);
            this.txtCliNombr.Name = "txtCliNombr";
            this.txtCliNombr.Size = new System.Drawing.Size(336, 20);
            this.txtCliNombr.TabIndex = 3;
            // 
            // txtClienteID
            // 
            this.txtClienteID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtClienteID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClienteID.Enabled = false;
            this.txtClienteID.Location = new System.Drawing.Point(78, 33);
            this.txtClienteID.Name = "txtClienteID";
            this.txtClienteID.Size = new System.Drawing.Size(75, 20);
            this.txtClienteID.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(386, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Nombre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(192, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Código Fox:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "ClienteID:";
            // 
            // errorIcono
            // 
            this.errorIcono.ContainerControl = this;
            // 
            // ttMensaje
            // 
            this.ttMensaje.IsBalloon = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(31, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clientes";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::CapaPresentacion.Properties.Resources.Logo_EMA_FC;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(335, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(293, 48);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // FrmClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(919, 531);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "FrmClientes";
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmClientes_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListado)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorIcono)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataListado;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Eliminar;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.CheckBox chkEliminar;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.TextBox txtCliNombr;
        private System.Windows.Forms.TextBox txtClienteID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider errorIcono;
        private System.Windows.Forms.ToolTip ttMensaje;
        private System.Windows.Forms.TextBox txtCliDirec;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCliTelef;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCliCPost;
        private System.Windows.Forms.TextBox txtCliLocal;
        private System.Windows.Forms.TextBox txtCliFax;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCliPCobr;
        private System.Windows.Forms.TextBox txtCliProve;
        private System.Windows.Forms.TextBox txtCliIngbr;
        private System.Windows.Forms.TextBox txtCliCuit;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCliTeadm;
        private System.Windows.Forms.TextBox txtCliCoadm;
        private System.Windows.Forms.TextBox txtCliTetec;
        private System.Windows.Forms.TextBox txtCliCotec;
        private System.Windows.Forms.TextBox txtCliCocom;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtCliOk;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtCliMail;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cboBuscar;
        private System.Windows.Forms.Button btnImprimirCodClien;
        private System.Windows.Forms.Button btnImprimirNombreCli;
        private System.Windows.Forms.TextBox txtCliTecom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox txtCliCIva;
        private System.Windows.Forms.ComboBox txtCliAgper;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtCliProvi;
        private System.Windows.Forms.TextBox txtCliCodigo;
        private System.Windows.Forms.TextBox txtCliPais;
    }
}